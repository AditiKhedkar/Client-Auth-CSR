export default function About() {
  return (
    <div>
      <h1>About Page</h1>
      <p>This page is statically generated at build time.</p>
    </div>
  );
}
